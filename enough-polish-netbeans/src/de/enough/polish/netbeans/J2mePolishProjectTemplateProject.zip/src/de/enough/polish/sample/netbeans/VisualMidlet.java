/*
 * VisualMidlet.java
 *
 * Created on 25 January 2006, 13:36
 */

package de.enough.polish.sample.netbeans;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

/**
 *
 * @author enough
 */
public class VisualMidlet extends MIDlet implements CommandListener {
        
    /** Creates a new instance of VisualMidlet */
    public VisualMidlet() {
        initialize();
    }
    
    private List list1;//GEN-BEGIN:MVDFields
    private Command exitCommand1;
    private Command screenCommand1;
    private Form form1;
    private Gauge gauge1;
    private TextField textField1;
    private StringItem stringItem1;
    private Command okCommand1;//GEN-END:MVDFields
    
//GEN-LINE:MVDMethods

    /** Called by the system to indicate that a command has been invoked on a particular displayable.//GEN-BEGIN:MVDCABegin
     * @param command the Command that ws invoked
     * @param displayable the Displayable on which the command was invoked
     */
    public void commandAction(Command command, Displayable displayable) {//GEN-END:MVDCABegin
    // Insert global pre-action code here
        if (displayable == list1) {//GEN-BEGIN:MVDCABody
            if (command == exitCommand1) {//GEN-END:MVDCABody
                // Insert pre-action code here
                exitMIDlet();//GEN-LINE:MVDCAAction5
                // Insert post-action code here
            } else if (command == list1.SELECT_COMMAND) {//GEN-BEGIN:MVDCACase5
                switch (get_list1().getSelectedIndex()) {
                    case 0://GEN-END:MVDCACase5
                        // Insert pre-action code here
                        getDisplay().setCurrent(get_form1());//GEN-LINE:MVDCAAction7
                        // Insert post-action code here
                        break;//GEN-BEGIN:MVDCACase7
                    case 1://GEN-END:MVDCACase7
                        // Insert pre-action code here
                        // Do nothing//GEN-LINE:MVDCAAction9
                        // Insert post-action code here
                        break;//GEN-BEGIN:MVDCACase9
                    case 2://GEN-END:MVDCACase9
                        // Insert pre-action code here
                        // Do nothing//GEN-LINE:MVDCAAction11
                        // Insert post-action code here
                        break;//GEN-BEGIN:MVDCACase11
                }
            } else if (command == screenCommand1) {//GEN-END:MVDCACase11
                // Insert pre-action code here
                // Do nothing//GEN-LINE:MVDCAAction13
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase13
        } else if (displayable == form1) {
            if (command == okCommand1) {//GEN-END:MVDCACase13
                // Insert pre-action code here
                getDisplay().setCurrent(get_list1());//GEN-LINE:MVDCAAction20
                // Insert post-action code here
            }//GEN-BEGIN:MVDCACase20
        }//GEN-END:MVDCACase20
    // Insert global post-action code here
}//GEN-LINE:MVDCAEnd

    /** This method initializes UI of the application.//GEN-BEGIN:MVDInitBegin
     */
    private void initialize() {//GEN-END:MVDInitBegin
        // Insert pre-init code here
        getDisplay().setCurrent(get_list1());//GEN-LINE:MVDInitInit
        // Insert post-init code here
    }//GEN-LINE:MVDInitEnd
    
    /**
     * This method should return an instance of the display.
     */
    public Display getDisplay() {//GEN-FIRST:MVDGetDisplay
        return Display.getDisplay(this);
    }//GEN-LAST:MVDGetDisplay
    
    /**
     * This method should exit the midlet.
     */
    public void exitMIDlet() {//GEN-FIRST:MVDExitMidlet
        getDisplay().setCurrent(null);
        destroyApp(true);
        notifyDestroyed();
    }//GEN-LAST:MVDExitMidlet

    /** This method returns instance for list1 component and should be called instead of accessing list1 field directly.//GEN-BEGIN:MVDGetBegin2
     * @return Instance for list1 component
     */
    public List get_list1() {
        if (list1 == null) {//GEN-END:MVDGetBegin2
            // Insert pre-init code here
            //#style mainScreen
            list1 = new List(null, Choice.IMPLICIT, new String[] {//GEN-BEGIN:MVDGetInit2
                "First selection",
                "Second element",
                "Third Element"
            }, new Image[] {
                null,
                null,
                null
            });
            list1.addCommand(get_exitCommand1());
            list1.addCommand(get_screenCommand1());
            list1.setCommandListener(this);
            list1.setSelectedFlags(new boolean[] {
                false,
                false,
                false
            });//GEN-END:MVDGetInit2
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd2
        return list1;
    }//GEN-END:MVDGetEnd2

    /** This method returns instance for exitCommand1 component and should be called instead of accessing exitCommand1 field directly.//GEN-BEGIN:MVDGetBegin4
     * @return Instance for exitCommand1 component
     */
    public Command get_exitCommand1() {
        if (exitCommand1 == null) {//GEN-END:MVDGetBegin4
            // Insert pre-init code here
            exitCommand1 = new Command("Exit", Command.EXIT, 1);//GEN-LINE:MVDGetInit4
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd4
        return exitCommand1;
    }//GEN-END:MVDGetEnd4

    /** This method returns instance for screenCommand1 component and should be called instead of accessing screenCommand1 field directly.//GEN-BEGIN:MVDGetBegin12
     * @return Instance for screenCommand1 component
     */
    public Command get_screenCommand1() {
        if (screenCommand1 == null) {//GEN-END:MVDGetBegin12
            // Insert pre-init code here
            screenCommand1 = new Command("Screen", Command.SCREEN, 1);//GEN-LINE:MVDGetInit12
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd12
        return screenCommand1;
    }//GEN-END:MVDGetEnd12

    /** This method returns instance for form1 component and should be called instead of accessing form1 field directly.//GEN-BEGIN:MVDGetBegin14
     * @return Instance for form1 component
     */
    public Form get_form1() {
        if (form1 == null) {//GEN-END:MVDGetBegin14
            // Insert pre-init code here
            //#style settingsForm
            form1 = new Form("Settings", new Item[] {//GEN-BEGIN:MVDGetInit14
                get_stringItem1(),
                get_gauge1(),
                get_textField1()
            });
            form1.addCommand(get_okCommand1());
            form1.setCommandListener(this);//GEN-END:MVDGetInit14
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd14
        return form1;
    }//GEN-END:MVDGetEnd14

    /** This method returns instance for gauge1 component and should be called instead of accessing gauge1 field directly.//GEN-BEGIN:MVDGetBegin15
     * @return Instance for gauge1 component
     */
    public Gauge get_gauge1() {
        if (gauge1 == null) {//GEN-END:MVDGetBegin15
            // Insert pre-init code here
            gauge1 = new Gauge("Tempo:", false, 100, 50);//GEN-LINE:MVDGetInit15
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd15
        return gauge1;
    }//GEN-END:MVDGetEnd15

    /** This method returns instance for textField1 component and should be called instead of accessing textField1 field directly.//GEN-BEGIN:MVDGetBegin17
     * @return Instance for textField1 component
     */
    public TextField get_textField1() {
        if (textField1 == null) {//GEN-END:MVDGetBegin17
            // Insert pre-init code here
            textField1 = new TextField("Your Name:", null, 120, TextField.ANY);//GEN-LINE:MVDGetInit17
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd17
        return textField1;
    }//GEN-END:MVDGetEnd17

    /** This method returns instance for stringItem1 component and should be called instead of accessing stringItem1 field directly.//GEN-BEGIN:MVDGetBegin18
     * @return Instance for stringItem1 component
     */
    public StringItem get_stringItem1() {
        if (stringItem1 == null) {//GEN-END:MVDGetBegin18
            // Insert pre-init code here
            stringItem1 = new StringItem("", "What\'s going on here?");//GEN-LINE:MVDGetInit18
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd18
        return stringItem1;
    }//GEN-END:MVDGetEnd18

    /** This method returns instance for okCommand1 component and should be called instead of accessing okCommand1 field directly.//GEN-BEGIN:MVDGetBegin19
     * @return Instance for okCommand1 component
     */
    public Command get_okCommand1() {
        if (okCommand1 == null) {//GEN-END:MVDGetBegin19
            // Insert pre-init code here
            okCommand1 = new Command("Ok", Command.OK, 1);//GEN-LINE:MVDGetInit19
            // Insert post-init code here
        }//GEN-BEGIN:MVDGetEnd19
        return okCommand1;
    }//GEN-END:MVDGetEnd19
    
    public void startApp() {
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
    }
    
}
