/******************************************************************
 * Copyright (C) Andrew Girow. All rights reserved.               *
 * ---------------------------------------------------------------*
 * This software is published under the terms of the TinyLine     *
 * SDK License, a copy of which has been included with this       *
 * distribution in the LICENSE file.                              *
 *****************************************************************/
package com.tinyline.app;

import javax.microedition.lcdui.*;

import com.tinyline.tiny2d.TinyRect;
import com.tinyline.svg.SVGPlayer;

/**
 * The <tt>MIDPSVGPlayer</tt> class implements <tt>SVGPlayer</tt>
 * for the J2ME MIDP2.0 platform.
 *
 * @author Andrew Girow
 * @version 1.5
 */

public class MIDPSVGPlayer extends  SVGPlayer
{

		ImageConsumer consumer;

		/**
     * Create a new <tt>MIDPSVGPlayer</tt>.
     */
    public MIDPSVGPlayer()
    {
    }

    /**
     * Sets the consumer for this <tt>MIDPSVGPlayer</tt>.
     */
    public void setConsumer(ImageConsumer consumer)
    {
        this.consumer = consumer;
    }


    /**
     * Returns true if this <tt>MIDPSVGPlayer</tt> has a consumer;
		 * otherwise returns false.
     */
    public boolean hasConsumer()
    {
        return (consumer!=null);
    }

    /**
     * Sends pixel data to the consumer.
     */
    public void sendPixels()
    {
				consumer.newPixels(clipRect.xmin, clipRect.ymin, clipRect.xmax - clipRect.xmin, clipRect.ymax - clipRect.ymin);
		}

    /**
     * Notifies the consumer.
     */
    public void  imageComplete()
    {
    }
}
