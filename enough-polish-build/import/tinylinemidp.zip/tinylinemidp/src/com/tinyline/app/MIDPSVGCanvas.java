/******************************************************************
 * Copyright (C) Andrew Girow. All rights reserved.               *
 * ---------------------------------------------------------------*
 * This software is published under the terms of the TinyLine     *
 * SDK License, a copy of which has been included with this       *
 * distribution in the LICENSE file.                              *
 *****************************************************************/
package com.tinyline.app;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import java.util.Vector;

import com.tinyline.tiny2d.TinyBitmap;
import com.tinyline.tiny2d.TinyHash;
import com.tinyline.svg.raster.SVGDocument;
import com.tinyline.svg.SVGPlayer;
import com.tinyline.svg.SVGEvent;
import com.tinyline.svg.raster.SVGImageElem;
import com.tinyline.svg.raster.ImageLoader;
import com.tinyline.svg.LinkWalker;
import com.tinyline.util.GZIPInputStream;


/**
 * This class represents a TinyLine SVG Canvas for MIDP 2.0.
 *
 * @author <a href="mailto:andrewgirow@yahoo.com">Andrew Girow</a>
 * @version 1.9
 */

/*
 * 2/16/2005 6:23PM
 *   Now I dont check for PNG only files, cause who knows may be some JVMs
 *   support JPG as well?
 * 2/17/2005 5:47PM
 *   Nokia UI support for bitmaps is added
 *
 */


public class MIDPSVGCanvas extends  Canvas
implements Runnable, ImageConsumer, ImageLoader, LinkWalker
{
		/* The clock image */
		Image wait;
		/* The SVGPlayer */
    MIDPSVGPlayer player;
		/* The current SVG document URL */
		String  currentURL="";
		/* The current loading status */
		boolean load = true;
		/* Pointer to the MIDlet */
    TinyLine viewer;

    /* The instance of a thread for asynchronous networking
		 * and user interface */
    Thread thread;

    /* The image cash */
    TinyHash imageCash;

		/* The UI modes */
		final static int  MODE_NEXTPREV  = 0;  // Navigation mode === Default mode
		final static int  MODE_PAN       = 1;  // Pan mode
		final static int  MODE_LINK      = 2;  // Link mode
		final static int  MODE_ZOOM      = 3;  // Zoom mode
		final static int  MODE_MAXCOUNT  = 4;  // MAX
		/* The mode index */
		int index;
		/* The current mode */
		int mode = MODE_NEXTPREV;

		/* The pointer device data */
    int pressedX;
    int pressedY;
    int draggedX;
    int draggedY;

		static final int PAN_STEP    = 4;
 	  static final int MENU_HEIGHT = 18;

		int x,y,width,height;

		/* Contructor a new MIDPSVGCanvas */
    public MIDPSVGCanvas(TinyLine aViewer)
    {
        viewer = aViewer;
        width = getWidth();
        height = getHeight();

				// Renderer
        player = new MIDPSVGPlayer();
        player.setConsumer(this);
				player.setLinkWalker(this);
				SVGImageElem.setImageLoader(this);
			  player.setAntialiased(true);
        player.setPixelbuffer(width, height);
				player.setSVGDocument(null);
        imageCash = new TinyHash(11);
    }

    /**
     * Starts this canvas thread
		 */
    public synchronized void start()
    {
        thread = new Thread(this);
        thread.start();
    }

    /**
     * Stops this canvas thread
		 */
    public synchronized void stop()
    {
				player.stop();
        thread = null;
    }

    /**
     * Fetch the specified currentURL in a separate thread and plays it
		 * in the renderer.
     * If the user cancels it, the thread be changed from this thread.
     */
    public void run()
    {

        try
        {
              // load the currentURL
              SVGDocument document = loadSVG(currentURL);
              player.setSVGDocument(document);
              player.start();
              Thread currentThread = Thread.currentThread();
              while (currentThread == thread)
              {
                  currentThread =  Thread.currentThread();
                  player.play();
                  thread.yield();
             }
        }
        catch (InterruptedException e)
        {
            viewer.alertError("Interrupted! ");
        }
			  catch( Throwable thr)
			  {
				    viewer.alertError("Internal Error");
			  }
    }

    /**
     * Inits this canvas
		 */
		void init()
		{
				try
        {
             wait = Image.createImage("/tinyline/wait.png");
			       // Load svg font
						 load = false;
						 // ? More or less the same time
						 //   Faster to use HelveticaFont class
						 // HelveticaFont.getFont();
        }
        catch(Exception e)
        {
						 viewer.alertError("Resources (helvetica.svg and/or icons) could not be loaded!");
        }
		}

    /**
     * Delivers the pixels of the image. The pixel (px,py) is
		 * stored in the pixels array at index (px * scansize + py + off).
     * @param x,&nbsp;y the coordinates of the upper-left corner of the
     *        area of pixels to be set
     * @param w the width of the area of pixels
     * @param h the height of the area of pixels
		 * @see  ImageConsumer
     */
    public void newPixels(int x, int y, int w, int h)
		{
				repaint(x,y,w,h);
				// paint it now!
				serviceRepaints();
		}

    /**
     * Loads <tt>TinyBitmap</tt> raster image.
     * @param imgRef The raster image URL.
     * @return The raster image.
		 * @ see ImageLoader Interface
     */
		public TinyBitmap createTinyBitmap(String imgRef)
		{
       TinyBitmap bitmap = null;
       if( imgRef.startsWith("..") || !imgRef.startsWith("http:"))
       {
          // This is relative path, then attach the basePath
          int p = currentURL.lastIndexOf('/');
          if(p!=-1)
          {
             imgRef = currentURL.substring(0,p)+'/' + imgRef;
          }
          else
          {
             return null;
          }
       }
       try
       {
           // check in the cash
           bitmap = (TinyBitmap)imageCash.get(imgRef);
           // not found
           if(bitmap == null)
           {
              bitmap = new TinyBitmap();
              Image image   = createImage(imgRef);
              bitmap.width  = image.getWidth();
              bitmap.height = image.getHeight();

              // Grap bits
              bitmap.pixels32 = new int[bitmap.width * bitmap.height];

           /**/
              // MIDP2.0 API
              image.getRGB(bitmap.pixels32, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height);
           /**/
           /*
           // Nokia Series 60 UI API
           // +10 pixels to have clear results
              Image bgImg = Image.createImage(bitmap.width+10,bitmap.height+10);
              Graphics bgG = bgImg.getGraphics();
              bgG.drawImage(image,0,0, bgG.TOP|bgG.LEFT);
              com.nokia.mid.ui.DirectUtils.getDirectGraphics(bgG).getPixels(
                 bitmap.pixels32, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height,
                 com.nokia.mid.ui.DirectGraphics.TYPE_INT_8888_ARGB);
            */
              imageCash.put(imgRef, bitmap);
           }
       }
       catch (Exception ex)
       {
           ex.printStackTrace();
       }
       return bitmap;
		}

    /**
     * Loads <tt> TinyBitmap </tt> raster image.
		 * @param imageData     The input image data buffer.
		 * @param imageOffset   The input image data buffer pointer.
		 * @param imageLength   The input image data buffer length.
     * @return The raster image.
		 * @ see ImageLoader Interface
     */
		public TinyBitmap createTinyBitmap(byte[] imageData, int imageOffset, int imageLength)
		{
        TinyBitmap bitmap = null;
        try
        {
           bitmap = new TinyBitmap();
					 Image image  =  Image.createImage(imageData, imageOffset, imageLength);
           bitmap.width  = image.getWidth();
           bitmap.height = image.getHeight();

					 // Grap bits
           bitmap.pixels32 = new int[bitmap.width * bitmap.height];
        /**/
           // MIDP2.0 API
           image.getRGB(bitmap.pixels32, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height);
        /**/
        /*
           // Nokia Series 60 UI API
           // +10 pixels to have clear results
           Image bgImg = Image.createImage(bitmap.width+10,bitmap.height+10);
           Graphics bgG = bgImg.getGraphics();
           bgG.drawImage(image,0,0, bgG.TOP|bgG.LEFT);
           com.nokia.mid.ui.DirectUtils.getDirectGraphics(bgG).getPixels(
                 bitmap.pixels32, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height,
                 com.nokia.mid.ui.DirectGraphics.TYPE_INT_8888_ARGB);
        */

        }
        catch (Throwable thr)
        {
           viewer.alertError("image could not be loaded.");
           return null;
        }
				return bitmap;
		}


    /**
     * Selects mode.
     * @param newmode The new mode id.
     */
		void selectMode( int newmode)
		{
				 if(mode == MODE_LINK)
				    player.hideFocus();
				 mode = newmode;
			   if(mode == MODE_LINK)
				    player.showFocus();
		}

    /**
     * Loads and dispalys an SVG document from the given URL.
		 * External hyperlinks handling
     * @param url The SVG document URL.
		 * @ see LinkWalker Interface
     */

    synchronized public void goURL(String url)
    {
				currentURL = url;
        start();
		}


    /**
     * Loads an SVG document.
     * @param url The SVG document URL.
     * @return The loaded document.
     */
		public SVGDocument loadSVG(String url)
		{
        System.out.println(""+url);
				load = true;
        repaint(0, height, getWidth(), MENU_HEIGHT);

			  SVGDocument doc = null;
        ContentConnection c = null;
        InputStream is = null;
 	      Runtime.getRuntime().gc();
			  try
			  {
            if (url.startsWith("/"))
            {
                is = getClass().getResourceAsStream(url);
            }
            else if (url.startsWith("http:"))
            {
                c = (ContentConnection)Connector.open(url);
                is = c.openInputStream();
                if(url.endsWith("svgz"))
                {
                    is = new GZIPInputStream(is);
                }
						}
						else
						{
						    viewer.alertError("Wrong URL "+ url);
				        load = false;
								return doc; // The stream is not open so it is safe to return
						}
						// Read and parse the stream
						doc = player.parse(is);
            load = true;
				}
				catch( IOException ioe)
				{
						viewer.alertError(ioe.getMessage() );
				}
        catch(OutOfMemoryError memerror)
        {
					  viewer.alertError("Not enought memory");
						doc = null;
						Runtime.getRuntime().gc();
        }
				catch( Throwable thr)
				{
						viewer.alertError("Not in SVGT format");
				}
        finally
        {
			      try
			      {
               if (is != null) is.close();
               if (c != null) c.close();
						}
				    catch( IOException ioe) {}
        }
				load = false;
				return doc;
		}


    /**
     * Draws the canvas
     * @param g The Graphics surface.
     */
    protected void paint(Graphics g)
    {
					// pixels
					if(!load)
					{
 /*
         // Nokia Series 60 UI API
					com.nokia.mid.ui.DirectGraphics dg = com.nokia.mid.ui.DirectUtils.getDirectGraphics(g);
					dg.drawPixels(player.getPixels32(),false,
               0,
               player.width,
               0,
               0,
               player.width,
               player.height,
               0,
               com.nokia.mid.ui.DirectGraphics.TYPE_INT_8888_ARGB);
 */

/**/

          // MIDP2.0 API
					g.drawRGB(player.getPixels32(),
               0,
               player.width,
               0,
               0,
               player.width,
               player.height,
               false);
 /**/
					}
					else //if(load)
					{
					   //draw the clock
						 g.setColor(0xffffff);
						 g.fillRect(0,0,width,height);
						 g.setColor(0x000000);
	           g.drawString("Wait ...", width/2, height/2,  Graphics.LEFT|Graphics.TOP);
					   if(wait!=null)
					   {
					      g.drawImage(wait,0,height-MENU_HEIGHT,
						                g.TOP|g.LEFT);
					   }
					}
		}


    /**
     * Handle keyboard input.
     * @param keyCode pressed key.
     */
    protected void keyRepeated(int keyCode)
    {
			 keyPressed(keyCode);
		}

		/**
     * Handle keyboard input.
     * @param keyCode pressed key.
     */
    protected void keyPressed(int keyCode)
    {
				if(load) return;
				int action = getGameAction(keyCode);
				switch (action)
				{
				     case Canvas.LEFT:
									if(mode == MODE_LINK)
                     player.prevFocus();
									else if(mode == MODE_PAN)
                     player.pan(-PAN_STEP,0);
									else if(mode == MODE_NEXTPREV)
										 previous();
 	                break;

						 case Canvas.RIGHT:
									if(mode == MODE_LINK)
                     player.nextFocus();
									else if(mode == MODE_PAN)
                     player.pan(PAN_STEP,0);
									else if(mode == MODE_NEXTPREV)
										 next();
 	                break;

						 case Canvas.UP:
									if(mode == MODE_LINK)
                     player.prevFocus();
									else if(mode == MODE_PAN)
                     player.pan(0,-PAN_STEP);
									else if(mode == MODE_ZOOM)
										 player.zoomIn();
 	                break;
				     case Canvas.DOWN:
									if(mode == MODE_LINK)
                     player.nextFocus();
									else if(mode == MODE_PAN)
                     player.pan(0,PAN_STEP);
									else if(mode == MODE_ZOOM)
										 player.zoomOut();
 	                break;
	           case Canvas.FIRE:
									if(mode == MODE_LINK)
										 player.focusPressed();
									break;
				} // end of switch
    }

    /**
     * Called when the pointer is released.
     * @param x - the X coordinate where the pointer was released.
     * @param y - the Y coordinate where the pointer was released.
     */
    protected void pointerReleased(int x, int y)
    {
				 if(load) return;
			   if(mode == MODE_LINK)
			   {
				     player.pointerReleased(x,y);
			   }
		     else if(mode == MODE_PAN)
		     {
		         player.pan(pressedX - x,pressedY - y);
		     }
		}

    /**
     * Called when the pointer is pressed.
     * @param x - the X coordinate where the pointer was pressed.
     * @param y - the Y coordinate where the pointer was pressed.
     */
    protected void pointerPressed(int x, int y)
    {
			   if(load) return;
		     if(mode == MODE_PAN)
		     {
             pressedX = x;
             pressedY = y;
             draggedX = pressedX;
             draggedY = pressedY;
			   }
		}

    /**
     * Called when the pointer is dragged.
     * @param x - the X coordinate where the pointer was dragged.
     * @param y - the Y coordinate where the pointer was dragged.
     */
		protected void pointerDragged(int x, int y)
    {
			   if(load) return;
		     if(mode == MODE_PAN)
		     {
             draggedX = x;
             draggedY = y;
			   }
		}

    /**
     * Go to the given image and update controls.
     * @param i index of the given image.
     */
		void go(int i)
		{
				index = i;
				goImpl(index);
		}

    /**
     * The go implemetation.
     * @param i index of the given image.
		 */
		private void goImpl(int i)
		{
				// update the List seletced position
				viewer.bookmarkList.setSelectedIndex(i,true);
				Bookmark bookmark = (Bookmark)viewer.bookmarks.elementAt(i);
				if(bookmark == null) return;
				goURL(bookmark.url);
		}

    /**
     * Advance to the next image and wrap around if necessary.
     */
    void next()
		{
        if ( index == viewer.bookmarks.size()-1)
				{
            return;
        }
        index++;
				goImpl(index);
    }

    /**
     * Back up to the previous image.
     * Wrap around to the end if at the beginning.
     */
    void previous()
		{
        if (index == 0)
        {
            return;
        }
        index--;
		    goImpl(index);
    }


    /**
     * Fetch the image.  If the name begins with "http:"
     * fetch it with connector.open and http.
     * If it starts with "/" then load it from the
     * resource file.
     * @param      name of the image to load
     * @return     image created
     * @exception  IOException if errors occuring doing loading
     */
    private Image createImage(String name) throws IOException
    {
        if (name.startsWith("/"))
        {
           return Image.createImage(name);
        }
        else if (name.startsWith("http:"))
        {
            // Load from a ContentConnection
            HttpConnection c = null;
            DataInputStream is = null;
            try
            {
               c = (HttpConnection)Connector.open(name);
               int status = c.getResponseCode();
               if (status != 200)
               {
                  throw new IOException("HTTP Response Code = " + status);
               }

               int len = (int)c.getLength();
               String type = c.getType();

               if (len > 0)
               {
                   is = c.openDataInputStream();
                   byte[] data = new byte[len];
                   is.readFully(data);
                   return Image.createImage(data, 0, len);
               }
               else
               {
                  throw new IOException("Content length is missing");
               }
            }
            finally
            {
               if (is != null)
                    is.close();
               if (c != null)
                    c.close();
            }
        }
        else
        {
            throw new IOException("Unsupported media");
        }
    }

}
