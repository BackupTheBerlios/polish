package de.enough.polish.ant.buildlistener;

import de.enough.polish.ExtensionSetting;

public class BuildListenerExtensionSetting extends ExtensionSetting {
	// no special settings so far
}
