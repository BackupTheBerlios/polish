mdevinf README.txt - This file is designed to be read using a fixed-width font
such as Courier or Monospace.

0) Contents
===========
  1)    Introduction
  
  2)    Application Files
  
  3)    Dependencies
  3.1)  WURFL
  
  4)    The Ant Build File Tasks
  4.1)  checkProps
  4.2)  clean
  4.3)  build
  4.4)  execute
  4.5)  document
  
  5)    The Source Files
  5.1)  MDevInf
  5.2)  WURFLInfo
  5.3)  Device
  5.4)  Group
  5.5)  QueryField
  5.6)  Description


1) Introduction
===============
This document has been written to provide a guide to the mDevInf application,
it's file contents and dependencies.

This file exists to (hopefully) relieve some of the frustrations that I have
experienced when trying to understand other open source projects.  However, in
order to stop the document growing to ridiculous proportions, some assumptions
need to be made.  These are (in no particular order):

   - You know how to retrieve files from the internet and install them
   - You have a working knowledge of Java and have the JDK installed (for this
     project, you will need JDK 1.5.0+, since it uses language features such as
     autoboxing that were not part of earlier versions)
   - You have a basic understanding of the Apache Ant build tool and have it
     installed.


2) Application Files
====================
Throughout this document, the abbreviation <mdevinf> is used to mean the
installation directory.

The complete project from the java.net CVS system contains the following files:

<mdevinf>/build/build.xml .............................. The Ant build file
<mdevinf>/Resources/capDesc.zip ........................ WURFL capability
                                                         descriptions
<mdevinf>/Resources/deviceIcon16.png ................... Icon used on device
                                                         hierarchy for real
                                                         devices
<mdevinf>/Resources/info16.png ......................... Info icon used on
                                                         information buttons
<mdevinf>/Resources/mDevInfIcon64.png .................. The main icon for
                                                         desktop shortcuts and
                                                         the About... dialog
<mdevinf>/Resources/mDevInfIcon.png .................... The window decoration
                                                         icon
<mdevinf>/Resources/mDevInfIconWS.png .................. The Web Start icon for
                                                         desktop shortcuts and
                                                         the About... dialog
<mdevinf>/Resources/mdevinf.jnlp ....................... A basic Web Start file
<mdevinf>/Resources/noDeviceIcon16.png ................. Icon used on device
                                                         hierarchy for fallback
                                                         devices
<mdevinf>/Resources/wurfl16.png ........................ Icon used for the root
                                                         of the device hierarchy
<mdevinf>/Resources/wurfl_logo.png ..................... Logo used on the WURFL
                                                         information dialog
<mdevinf>/Source/.../mdevinf/MDevInf.java ................ \
<mdevinf>/Source/.../mdevinf/model/Capability.java .......  |
<mdevinf>/Source/.../mdevinf/model/Description.java ......  |
<mdevinf>/Source/.../mdevinf/model/Device.java ...........  |
<mdevinf>/Source/.../mdevinf/model/Group.java ............  |
<mdevinf>/Source/.../mdevinf/model/MatchedDevice.java ....  |
<mdevinf>/Source/.../mdevinf/model/PatchManager.java .....  |
<mdevinf>/Source/.../mdevinf/model/Person.java ...........  |
<mdevinf>/Source/.../mdevinf/model/ValidationResult.java . /
<mdevinf>/Source/.../mdevinf/model/WURFLInfo.java ........ |
<mdevinf>/Source/.../mdevinf/model/WURFLTree.java ........ |
<mdevinf>/Source/.../mdevinf/ui/DevicePanelManager.java .. \  Application
<mdevinf>/Source/.../mdevinf/ui/DeviceRenderer.java ......  > Source
<mdevinf>/Source/.../mdevinf/ui/DocStyler.java ........... /  Files
<mdevinf>/Source/.../mdevinf/ui/EditField.java ........... |
<mdevinf>/Source/.../mdevinf/ui/EditorPanelManager.java .. |
<mdevinf>/Source/.../mdevinf/ui/InfoDisplayAction.java ... \
<mdevinf>/Source/.../mdevinf/ui/NewCapabilityDialog.java .  |
<mdevinf>/Source/.../mdevinf/ui/NewDeviceDialog.java .....  |
<mdevinf>/Source/.../mdevinf/ui/QueryField.java ..........  |
<mdevinf>/Source/.../mdevinf/ui/RelPanelManager.java .....  |
<mdevinf>/Source/.../mdevinf/ui/ResultsPanelManager.java .  |
<mdevinf>/Source/.../mdevinf/ui/SearchPanelManager.java ..  |
<mdevinf>/Source/.../mdevinf/ui/TabbedPaneManager.java ...  |
<mdevinf>/Source/.../mdevinf/ui/UAPanelManager.java ......  |
<mdevinf>/Source/.../mdevinf/ui/WURFLInfoDialog.java ..... /
LICENSE.txt ............................................ GPL license
README.txt ............................................. This file
RUNNING.txt ............................................ How to run mDevInf
TODO.txt ............................................... Future ideas

Please note that the application will not build or execute correctly unless the
dependencies described below are met.



3) Dependencies
===============
mDevInf depends on the WURFL zip file.  WURFL 1 and WURFL 2 files are supported.

3.1) WURFL
----------
The WURFL zip file is available from http://wurfl.sourceforge.net/

Note that in July 2005, the WURFL file was extensively modified and many
capabilities were added and removed.  However, because mDevInf uses the content
as defined in the file (rather than any fixed capability list), it works
transparently with either a WURFL 1 or WURFL 2 file.

Regardless of the version you use, you should ensure that the file exists as
"<mdevinf>/Resources/wurfl.zip".

To support the WURFL zip file, the descriptions of each of the capabilities
(as provided at http://wurfl.sourceforge.net/help_doc.php) have been converted
into an XML file, zipped up and stored as "<mdevinf>/Resources/capDesc.zip".


4) The Ant Build File Tasks
===========================
This section of the document explains the purpose of each of the ant build file
tasks.

To execute one of the tasks, go into the <mdevinf>/build directory and type the
following:

    > ant {taskname}
    
If you don't supply a {taskname}, Ant assumes the default task - in this case,
"execute" (see 4.4).

4.1) checkProps
----------------
This task checks that the dependencies are all in place.  If any dependencies
cannot be found, the build is stopped and an error message is displayed that
should help you to solve the problem.

4.2) clean
-----------
This task removes the directories containing any output files from previous
builds and recreates them.  The directories are:

    <mdevinf>/build/bin .............. (where the JAR file is written)
    <mdevinf>/classes ................ (where the .class files are written)
    
The "clean" task depends on "checkProps".

4.3) compile
------------
This task compiles the .java files from <mdevinf>/Source into <mdevinf>/classes.

4.4) build
----------
This task creates the stand-alone executable file 
<mdevinf>/build/bin/mdevinf.jar.
The mdevinf.jar file contains the "Main-Class" attribute for the manifest.  This
make the jar file executable.  This simplifies things for the end user because
the application can be executed using:

    > java -jar mdevinf.jar
    
instead of:

    > java -classpath mdevinf.jar com.ossltd.mdevinf.MDevInf
    
The "build" task depends on "clean" to ensure a clean build each time.

Note that the stand-alone executable MUST NOT contain the mDevInfIconWS.png
file.  The application looks for this file at startup and if found, it is
assumed that the Web Start (resource restricted) version of the application is
running.  This will prevent many features working - no loading of local
WURFL or patch files and no editing facilities.

4.5) webstartbuild
------------------
This task creates the Java Web Start build file mDevInfWS.zip.  This file
contains the executable JAR (but without the integrated wurfl.zip file) and all
the necessary resources, wrapped in JAR files:

   - wurfl.jar (containing wurfl.zip)
   - capDesc.jar (containing capDesc.zip)
   - images.jar (containing all the .PNG images from the resources directory)

4.6) execute [default]
----------------------
This task executes the application.

The "execute" task depends on "build" to ensure that the latest version of the
application is run.

4.7) document
--------------
This task is used to create the Javadoc API documentation.  It creates a
directory <mdevinf>/docs (first deleting the directory if it already exists).

4.8) createDistroPackages
-------------------------
This task creates the source and binary distribution packages.

5 The Source Files
==================
For detailed information, see the API documentation generated with the
"document" Ant task.
