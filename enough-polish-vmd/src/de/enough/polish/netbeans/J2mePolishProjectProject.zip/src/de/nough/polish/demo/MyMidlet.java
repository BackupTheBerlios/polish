/*
 * MyMidlet.java
 *
 * Created on January 20, 2006, 6:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package de.nough.polish.demo;

/**
 *
 * @author robertvirkus
 */
public class MyMidlet {
    
    /** Creates a new instance of MyMidlet */
    public MyMidlet() {
    }
    
}
